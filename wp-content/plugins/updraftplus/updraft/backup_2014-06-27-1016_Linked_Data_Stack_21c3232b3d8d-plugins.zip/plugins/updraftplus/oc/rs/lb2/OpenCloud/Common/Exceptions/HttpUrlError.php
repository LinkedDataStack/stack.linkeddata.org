<?php

namespace OpenCloud\Common\Exceptions;

class HttpUrlError extends \Exception {}

<?php

namespace OpenCloud\Common\Exceptions;

class CdnHttpError extends \Exception {}

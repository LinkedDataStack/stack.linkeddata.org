<?php

namespace OpenCloud\Common\Exceptions;

class DatabaseNameError extends \Exception {}

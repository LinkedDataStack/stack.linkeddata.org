<?php

namespace OpenCloud\Common\Exceptions;

class NetworkUpdateError extends \Exception {}

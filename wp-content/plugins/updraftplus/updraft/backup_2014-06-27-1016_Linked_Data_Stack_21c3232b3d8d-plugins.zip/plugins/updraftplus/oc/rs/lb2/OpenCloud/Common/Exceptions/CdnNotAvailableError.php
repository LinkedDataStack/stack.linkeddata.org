<?php

namespace OpenCloud\Common\Exceptions;

class CdnNotAvailableError extends \Exception {}

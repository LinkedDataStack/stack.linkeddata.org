<?php

namespace OpenCloud\Common\Exceptions;

class MetadataPrefixError extends \Exception {}

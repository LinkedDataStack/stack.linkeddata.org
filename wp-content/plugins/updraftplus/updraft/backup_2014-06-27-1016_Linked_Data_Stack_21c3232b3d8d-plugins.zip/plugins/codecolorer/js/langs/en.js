tinyMCE.addI18n('en.codecolorer',{
  codecolorer_desc: 'Insert CodeColorer snippet',
  delta_width: 0,
  delta_height: 0
});
